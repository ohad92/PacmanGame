# Assignment2
 
Link: https://web-development-environments-2021.github.io/Assignment2_314983438_203665401/

Ronen Aranovich - 314983438, ronenara@post.bgu.ac.il

Ohad Shriki - 203665401, ohadshr@post.bgu.ac.il

We added those functionalities:

-	Heart- if pacman eats heart he gets additional live.

-	Poison- if pacman eats poison he loses live

-	Hourglass- if pacman eats hourglass the player has additional 10 seconds to play the game (only appears if score is less than 500).

All those features reappear every five seconds at random locations in the map.


